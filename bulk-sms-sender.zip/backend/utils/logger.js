const logger = (message) => {
  console.log(message);
};

module.exports = { logger };