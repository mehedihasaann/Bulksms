const validateInput = (input) => {
  return input && input.trim() !== '';
};

module.exports = { validateInput };