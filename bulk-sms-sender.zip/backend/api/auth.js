const express = require('express');
const router = express.Router();

// Authentication API placeholder
router.post('/login', (req, res) => {
  res.json({ message: 'Login successful' });
});

module.exports = router;