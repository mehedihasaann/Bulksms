const express = require('express');
const router = express.Router();

// Analytics placeholder
router.get('/campaigns', (req, res) => {
  res.json({ message: 'Campaign analytics coming soon!' });
});

module.exports = router;