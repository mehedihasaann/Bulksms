const axios = require('axios');

// Send SMS via Twilio
async function sendSMS(to, message) {
  const url = `https://api.twilio.com/2010-04-01/Accounts/${process.env.TWILIO_SID}/Messages.json`;
  const auth = {
    username: process.env.TWILIO_SID,
    password: process.env.TWILIO_AUTH_TOKEN,
  };

  const data = {
    To: to,
    From: process.env.TWILIO_PHONE_NUMBER,
    Body: message,
  };

  const response = await axios.post(url, new URLSearchParams(data), {
    auth,
  });

  return response.data;
}

module.exports = { sendSMS };