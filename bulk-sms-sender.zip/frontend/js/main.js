const API_BASE_URL = 'https://your-domain.com/api';

async function sendMessage() {
  const message = document.getElementById('messageInput').value;
  const recipient = document.getElementById('recipientInput').value;

  const response = await fetch(`${API_BASE_URL}/sms/send`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ to: recipient, message }),
  });

  const result = await response.json();
  if (result.success) {
    alert('Message sent successfully!');
  } else {
    alert('Failed to send message!');
  }
}