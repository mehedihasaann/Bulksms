# Installation Guide

1. Set up backend dependencies.
2. Configure `.env` file.
3. Deploy to server.