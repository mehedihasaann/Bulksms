# Bulk SMS Sender

A full-featured bulk SMS sender and receiver application supporting multiple platforms and APIs.