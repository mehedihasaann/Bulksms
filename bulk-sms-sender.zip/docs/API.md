# API Documentation

## SMS Endpoints
- `/api/sms/send` - Send SMS to a recipient.